<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => $__env->getContainer()->make(Illuminate\View\Factory::class)->make('mail::message'),'data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mail::message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
# Applican informations

<strong>First Name</strong> : <?php echo e($data->firstName); ?> <br>
<strong>Last Name</strong> : <?php echo e($data->lastName); ?> <br>
<strong>Sur Name</strong> : <?php echo e($data->surName); ?> <br>
<strong>Address</strong> : <?php echo e($data->address); ?> <br>
<strong>Email Address</strong> : <?php echo e($data->emailAddress); ?> <br>
<strong>Phone Number</strong> : <?php echo e($data->phoneNumber); ?> <br>
<strong>Region</strong> : <?php echo e($data->region); ?> <br>
<strong>Pincode</strong> : <?php echo e($data->pincode); ?> <br>
<strong>Country</strong> : <?php echo e($data->country); ?> <br>
<strong>State</strong> : <?php echo e($data->state); ?> <br>
<strong>City</strong> : <?php echo e($data->city); ?> <br>
<strong>Qualification</strong> : <?php echo e($data->qualification); ?> <br>
<strong>Birth Date</strong> : <?php echo e($data->birth_date); ?> <br>
<strong>Gender</strong> : <?php echo e($data->genderOption); ?> <br>

Nearby, there are my image and my resume
<br>
Thanks,<br>
<?php echo e(config('app.name')); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH /home/stephane/projects/laravel/tests/task1/resources/views/email/information.blade.php ENDPATH**/ ?>