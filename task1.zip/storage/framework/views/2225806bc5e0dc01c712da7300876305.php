<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['field']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['field']); ?>
<?php foreach (array_filter((['field']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if($errors->has($field)): ?>
    <span class="text-danger">
        <?php echo e($errors->first($field)); ?>

    </span>
<?php endif; ?><?php /**PATH /home/stephane/projects/laravel/tests/task1/resources/views/components/error.blade.php ENDPATH**/ ?>