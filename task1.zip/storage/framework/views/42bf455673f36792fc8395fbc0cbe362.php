<?php echo e($slot); ?>

<?php /**PATH /home/stephane/projects/laravel/tests/task1/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>