<?php

return [
    'emails' => [
        'stephaneassocle@gmail.com'
    ]
];